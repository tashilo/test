import shutil

learn_python = shutil.make_archive("learn_python", "zip")
